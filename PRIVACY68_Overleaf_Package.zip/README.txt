============================================================
PRIVACY68 -- MCA FINAL DISSERTATION REPORT (OVERLEAF PACKAGE)
A. J. Institute of Engineering and Technology (AJIET) Mangaluru
Department of Master of Computer Applications (MCA)
============================================================

COMPLETE PACKAGE WITH PRE-BUNDLED FIGURES:
------------------------------------------
This package includes the complete dissertation source code along with
all 10 high-resolution monochrome system architecture, DFD, UML, sequence,
testing, and interface figures in the 'figures/' folder:

- figures/architecture-diagram.png (Figure 4.1: Five-Layer Architecture)
- figures/dfd-level-0.png          (Figure 4.2: DFD Level 0 Context)
- figures/dfd-level-1.png          (Figure 4.3: DFD Level 1 Decomposition)
- figures/use-case-diagram.png     (Figure 4.4: UML Use Case Diagram)
- figures/sequence-diagram.png     (Figure 4.5: Telegram Sequence Diagram)
- figures/testing-hierarchy.png    (Figure 6.1: Testing Strategy Hierarchy)
- figures/control-center.png       (Figure 7.1: WebView2 Control Center)
- figures/quick-command-bar.png    (Figure 7.2: Quick Command Bar HUD)
- figures/screenshot-response.png   (Figure 7.4: Remote Screenshot Output)
- figures/security-confirmation.png(Figure 7.5: 15s Critical Safety Confirmation)

HOW TO USE IN OVERLEAF:
-----------------------
1. Log in to your Overleaf account (https://www.overleaf.com).
2. Click 'New Project' -> 'Upload Project'.
3. Select this 'PRIVACY68_Overleaf_Package.zip' file.
4. Overleaf will extract the project and open 'main.tex'.
5. In the left panel, click 'Menu' (top-left) and confirm:
   - Compiler: pdfLaTeX
   - TeX Live version: 2023 or 2024 / Latest
   - Main document: main.tex
6. Click 'Recompile' (or press Ctrl+Enter). The complete 100-150 page
   dissertation PDF with all diagrams will generate instantly!
